# AI-Powered Hospital Assistance and Triage
## Academic Project Report Draft

**Programme:** B.Tech Computer Science and Engineering (Artificial Intelligence and Machine Learning)  
**Institution:** Lovely Professional University, Punjab, India  
**Team:** [Member 1], [Member 2], [Member 3], [Member 4]  
**Version:** 1.0

> **Important:** This report describes an educational prototype. It does not present a clinically validated triage protocol or medical device.

## Abstract
This project presents a local web-based educational prototype for organising fictional patient records and demonstrating transparent, rule-based reasoning. The system provides patient registration, a dashboard, record search and filtering, administrative queue management, CSV exports, and a rule trace that explains the configured rule associated with a provisional category. Python and Streamlit provide the application interface, SQLite stores records, and a JSON knowledge base stores the illustrative rules. The system is designed to demonstrate knowledge representation and explainable rule-based logic. It does not diagnose conditions, use a trained machine-learning model, or replace professional healthcare assessment. All example data is synthetic, and all categories require human review.

## 1. Introduction
Hospitals coordinate patient information, staff review, and patient flow. Software can help organise administrative information, but systems that affect clinical decisions require careful validation, oversight, privacy protections, and appropriate governance. This project uses a deliberately limited educational prototype to demonstrate how structured information, configurable rules, and transparent explanations can be represented in software.

## 2. Problem Statement
A student project needs a practical demonstration of how AI concepts can be represented in a hospital-assistance workflow without claiming to make real clinical decisions. The prototype should organise fictional records, show a traceable rule outcome, and demonstrate queue management.

## 3. Objectives
- Create a web interface for fictional patient registration.
- Store records in a local database.
- Demonstrate a configurable rule-based inference process.
- Explain which rule produced each provisional category.
- Organise records in an administrative queue.
- Present aggregate dashboard statistics and exports.
- Test key database, rule-engine, and queue behaviours.
- Document limitations and safe educational use.

## 4. Scope
The scope is a local academic prototype using synthetic data. It includes record management, illustrative rules, explanation traces, administrative status changes, and CSV export. It excludes real diagnosis, clinical validation, production deployment, and autonomous medical decision-making.

## 5. Existing and Proposed System
A manual administrative workflow can make it difficult to demonstrate consistent record organisation and traceable rule paths in a student project. The proposed prototype provides a single local interface for fictional records, deterministic rule outcomes, and explanations. This is a software demonstration rather than evidence that the system improves clinical outcomes.

## 6. Requirements
### Functional
1. Register a fictional patient.
2. Validate required fields and age range.
3. Save and retrieve records.
4. Apply the educational ruleset.
5. Display the rule explanation.
6. Search and filter records.
7. Update review and queue status.
8. Sort the administrative queue.
9. Display aggregate statistics.
10. Export records and summary CSV files.

### Non-functional
- Readable, modular Python code.
- Local persistence with SQLite.
- Transparent rule outcomes.
- Graceful handling of invalid inputs.
- Synthetic data by default.
- Explicit safety limitations.

## 7. Technology Stack
- Python: application logic.
- Streamlit: interactive web UI.
- SQLite: local database.
- Pandas: data table and CSV handling.
- Plotly: dashboard visualisation.
- pytest: automated tests.

## 8. System Architecture
The UI receives user input and calls service functions. The triage engine reads the JSON knowledge base and returns a provisional category, explanation, and triggered rule identifier. The database layer stores patient information and administrative status. The reporting service prepares tables and aggregate exports.

```text
User
  |
Streamlit UI
  |--------------------|
  |                    |
Triage Service     Database Service
  |                    |
JSON Knowledge Base   SQLite
  |
Rule trace + provisional category
  |
UI explanation / human-review notice
```

## 9. Database Design
The `patients` table stores a generated record ID, demo code, display name, age, selected symptom group, symptom description, duration, observations, input flags, provisional category, explanation, triggered rule IDs, review status, queue status, and timestamps. The `audit_events` table records administrative events such as creation, status updates, and deletion. SQLite foreign-key support is enabled.

## 10. AI Methodology
The prototype demonstrates a small deterministic rule-based system. The knowledge base is a JSON file containing rule identifiers, purpose, conditions, outcome, explanation, and safety notes. The `assess()` function evaluates the emergency-warning flag first, then incomplete information, explicit review requests, and the selected demonstration group. It returns the configured outcome and explanation.

This is a rule-based educational demonstration; it is not a trained machine-learning model. The input flags are supplied by the demo user, not inferred from clinical observations. The rules have not been clinically validated.

## 11. Explainability
Each assessment stores the identifier of the rule that matched and the corresponding explanation. The UI shows the explanation and a summary of the inputs used. This makes the software path inspectable, but a transparent rule is not necessarily a correct or safe clinical rule.

## 12. Patient Flow and Queue
Records in Waiting or In review status appear in the administrative queue. The display sort order uses a fixed demonstration category order, followed by creation timestamp and record ID. This is a predictable software sorting mechanism, not a clinically approved queue policy. Staff must not use the prototype to determine real-world urgency.

## 13. Privacy and Safety
Only fictional sample data should be used. The application is intended for local academic demonstration and does not include production-grade authentication or access controls. It should not be exposed publicly or used to store real patient information. A possible emergency-warning selection triggers a safety message; the application cannot detect all emergencies and the example is not exhaustive.

## 14. Testing
Automated tests are provided for selected triage outcomes, knowledge-base loading, database operations, age validation, queue ordering, and empty queues. Run `python -m pytest -q` from the project root. Insert actual test output into the final report after execution. Passing unit tests would demonstrate only the tested software behaviours, not clinical validity.

## 15. Results and Discussion
The intended prototype workflow supports registration, storage, review, administrative queue sorting, explanations, and exports. The final report should include actual screenshots and observed test output after running the application in the target environment. No performance or clinical outcome claims are made.

## 16. Limitations
- Educational rules are not clinically validated.
- No machine-learning model is trained.
- The emergency flag is user-selected and is not an automated detector.
- No production-grade authentication or multi-user access control.
- Local testing may differ from the target laptop.
- A successful software test does not establish medical safety.

## 17. Future Enhancements
Potential future work includes a clinician-reviewed requirements process, usability evaluation, stronger authentication and authorisation, structured audit controls, deployment security, and responsible evaluation of any future ML model using appropriate governance and validated data.

## 18. Conclusion
The project demonstrates a practical combination of web development, local data persistence, rule-based reasoning, explainability, queue organisation, and software testing. Its main educational contribution is showing how a small knowledge-based system can produce inspectable outputs while explicitly communicating its limitations. It must remain a synthetic-data academic prototype and must not be used for clinical decisions.

## References
See `REFERENCES.md` for official technology documentation starting points. Add verified clinical and academic sources if required by the course. Verify all bibliographic details before submission.
