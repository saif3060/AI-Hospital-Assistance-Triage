# References

The following are general official documentation starting points. Consult them when writing or presenting the project and verify the current pages and access dates before final submission.

- Python documentation: https://docs.python.org/3/
- Streamlit documentation: https://docs.streamlit.io/
- SQLite documentation: https://www.sqlite.org/docs.html
- Pandas documentation: https://pandas.pydata.org/docs/
- Plotly Python documentation: https://plotly.com/python/
- pytest documentation: https://docs.pytest.org/

This list documents technology references; it is not a clinical literature review. Add verified, relevant research and authoritative healthcare sources if required by the instructor.
