# Viva Preparation: AI-Powered Hospital Assistance and Triage

## 30-second explanation
“Our project is an educational web prototype that demonstrates how a hospital assistance system can organise fictional patient records, apply transparent rule-based logic to produce provisional categories, explain which rule was triggered, and manage an administrative queue. It is not a medical diagnosis system and its rules are not clinically validated.”

## Two-minute explanation
“The application is built with Python and Streamlit, and uses SQLite for local persistence. The UI supports registration, searching and filtering records, viewing explanations, updating queue status, and exporting CSV reports. The triage engine is a deterministic rule-based system. It reads a JSON knowledge base, checks input flags and an illustrative symptom group, and returns a configured category plus the rule identifier and explanation. All outputs require professional assessment. The project demonstrates knowledge representation and explainability, but it does not train an ML model. We test the core rules, database operations, and queue ordering with synthetic data.”

## Key technical questions
**Q: What makes this an AI project?**  
A: The prototype demonstrates a small knowledge-based, rule-driven inference system. It is a limited AI technique, not machine learning.

**Q: What is the knowledge base?**  
A: A JSON file containing rule IDs, purposes, conditions, outcomes, explanations, and safety notes.

**Q: What is the inference engine?**  
A: The Python function `assess()` that evaluates the input conditions in a defined order and returns a result and trace.

**Q: Is the model trained?**  
A: No. This version uses deterministic rules and does not train a machine-learning model.

**Q: Why use SQLite?**  
A: It is lightweight, local, requires no separate database server, and is suitable for a college prototype.

**Q: Why use Streamlit?**  
A: It allows a Python-first interactive web UI with relatively little setup.

**Q: How are explanations generated?**  
A: Each result includes the ID and explanation of the configured rule that matched.

**Q: How is the queue sorted?**  
A: It uses a fixed display order for demonstration categories, then timestamp and record ID. This is not a clinical protocol.

**Q: What testing is included?**  
A: Automated tests cover rule paths, invalid ages, database CRUD operations, and queue sorting. Report only results actually observed when running the tests.

**Q: What are the limitations?**  
A: Rules are not clinically validated, there is no trained ML model, authentication is not production-grade, and the application is for synthetic local demonstrations only.

**Q: What future work is possible?**  
A: Clinician-reviewed requirements, formal safety analysis, usability testing, stronger access controls, and responsibly governed evaluation of any future ML component.

## Demo walkthrough
1. Open Overview and explain the disclaimer.
2. Show the seeded fictional records.
3. Register a new fictional record.
4. Select the possible emergency-warning checkbox only as a software-path demonstration and show the safety message.
5. Open Explainable AI and show the triggered rule.
6. Open Queue Management and explain display ordering.
7. Export a CSV report.
8. Explain that no real clinical decisions should be based on this prototype.
