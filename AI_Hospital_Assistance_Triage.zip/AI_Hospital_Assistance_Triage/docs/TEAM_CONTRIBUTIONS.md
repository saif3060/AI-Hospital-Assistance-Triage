# Suggested Team Contribution Plan

Replace placeholders with the actual names and update the table to reflect work genuinely completed. This is a suggested plan, not a claim about past contributions.

| Team member | Suggested responsibility | Example deliverables |
|---|---|---|
| Member 1: [Name] | UI and user experience | Streamlit pages, layout, usability review |
| Member 2: [Name] | Database and patient records | SQLite schema, CRUD operations, validation |
| Member 3: [Name] | Knowledge base and rule engine | JSON rules, inference logic, explanations |
| Member 4: [Name] | Testing and documentation | Automated tests, report, presentation, demo checklist |

All team members should understand the project overview, safety limitations, architecture, and actual implementation before the viva.
