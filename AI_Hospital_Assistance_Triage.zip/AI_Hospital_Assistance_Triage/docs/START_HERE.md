# Start Here

1. Extract the ZIP archive.
2. Open the extracted `AI_Hospital_Assistance_Triage` folder.
3. Open PowerShell in that folder.
4. Create and activate a virtual environment:
   `py -m venv .venv`
   `.\.venv\Scripts\Activate.ps1`
5. Install dependencies: `pip install -r requirements.txt`
6. Start the app: `streamlit run app.py`
7. Run tests in a second terminal: `python -m pytest -q`
8. Read `README.md`, then `docs/PROJECT_REPORT.docx` and `docs/VIVA_PREPARATION.md`.

Only use fictional data. This is not a clinical tool.
