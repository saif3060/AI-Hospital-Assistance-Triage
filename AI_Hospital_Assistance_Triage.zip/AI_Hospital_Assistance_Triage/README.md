# AI-Powered Hospital Assistance and Triage

A local, educational Streamlit application demonstrating patient-record management, a transparent rule-based triage example, an administrative queue, and explainable rule traces.

> **Safety notice:** This is an educational prototype only. It is not a medical device, diagnosis tool, or clinically validated triage system. Never use its categories to make real healthcare decisions. In an emergency, contact local emergency services or seek immediate professional assessment. Use synthetic data only.

## Features
- Patient registration with input validation
- SQLite persistence and synthetic demo records
- Configurable JSON knowledge base
- Provisional categories with triggered-rule explanations
- Patient record search, filtering, review flag, and queue status management
- Administrative queue ordering and CSV exports
- Dashboard charts and aggregate statistics
- Audit events for record creation, status changes, and deletion
- Automated tests for triage rules, database operations, and queue sorting

## Technology
Python, Streamlit, SQLite, Pandas, Plotly, pytest.

This prototype uses deterministic rule-based logic, not a trained machine-learning model. Charts, filtering, database persistence, and status changes are conventional software functionality.

## Windows 11 setup
Install Python 3.10 or newer from the official Python website and ensure Python is available in your terminal.

Open PowerShell in this project directory and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Streamlit will print a local address, usually `http://localhost:8501`, which you can open in your browser.

If PowerShell blocks activation, use Command Prompt:
```bat
py -m venv .venv
.venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

## Run tests
```powershell
python -m pytest -q
```

## Data and reset
The app creates `hospital_triage.db` locally and seeds four fictional records when the database is empty. To reset demo data, stop the app, delete `hospital_triage.db`, and restart. Do not store real patient information in this demo.

## Main files
- `app.py`: Streamlit UI and page routing
- `database/database.py`: SQLite schema and persistence
- `services/triage_engine.py`: rule evaluation and explanation output
- `knowledge_base/triage_rules.json`: editable educational rules
- `services/queue_service.py`: administrative queue sorting
- `tests/`: automated tests
- `docs/`: project report and viva documents
- `presentation/`: PowerPoint presentation

## Known limitations
- Rules are illustrative and not medically validated.
- No production-grade authentication, access control, or deployment hardening.
- The emergency-warning flag is selected by the demo user; the app does not detect emergencies.
- No ML model has been trained.
- Test outcomes depend on the environment in which tests are run.
